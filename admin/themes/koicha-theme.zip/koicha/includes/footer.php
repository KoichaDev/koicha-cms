  <footer class="page-footer font-small mdb-color" style="background-color: #F7F7F7;">
    <div class="container text-center text-md-left">
      <div class="row">      
        <div class="col-md-4 col-lg-4 text-center mx-auto my-4">
          <p>🔥 <strong>Designed & Developed by Khoi Hoang</strong> 🔥</p>
          <a type="button" href="https://www.linkedin.com/in/khohoa/" class="btn-floating btn-fb">
            <i class="fa fa-linkedin-square"></i>
          </a>
          <a type="button" href="https://github.com/KoichaDev" class="btn-floating btn-tw">
            <i class="fa fa-github" style="width: 1.875rem;"></i> 
          </a>
          <a href="mailto: hello@koicha.dev" class="btn-floating btn-mail">
            <i class="fa fa-envelope"></i>
          </a>
        </div>
      </div>
  </footer>
</body>
</html>