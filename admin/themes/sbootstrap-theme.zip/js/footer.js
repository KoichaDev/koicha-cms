// Intantiate a date Object
const date = new Date();
// Displaying the current Full Year
document.querySelector('.current-date').innerHTML = date.getFullYear();